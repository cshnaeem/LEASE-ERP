﻿using System;
using System.Collections.Generic;
using System.Data.Entity;
using System.Linq;
using System.Net.Http;
using System.Net.Http.Headers;
using System.Threading.Tasks;
using System.Web;

namespace AGEERP.Models
{
    public class SMSBL
    {
        
        AGEEntities db = new AGEEntities();

        public async Task<string> Send(string number, string msg)
        {
            string resp = "";
            try
            {
                //BIZ SMS
                //if (number.Substring(0, 1) == "0")
                //{
                //    number = "92" + number.Substring(1, number.Length - 1);
                //}
                //client.BaseAddress = new Uri("http://api.bizsms.pk/");
                //client.DefaultRequestHeaders.Accept.Clear();
                //client.DefaultRequestHeaders.Accept.Add(
                //    new MediaTypeWithQualityHeaderValue("application/json"));
                //HttpResponseMessage response = await client.GetAsync("api-send-branded-sms.aspx?username=d-sales-ay@bizsms.pk&pass=s3al229d&text=" + msg + "&masking=Demo&destinationnum=" + number + "&language=English");
                //if (response.IsSuccessStatusCode)
                //{
                //    var res = await response.Content.ReadAsStringAsync();
                //    int pos1 = res.IndexOf(@"lblmessage") + 12;
                //    int pos2 = res.Substring(pos1).IndexOf("</span></b>");
                //    resp = res.Substring(pos1, pos2);
                //}
                //if (resp == "SMS Sent Successfully.")
                //{
                //    return "S";
                //}
                //else
                //{
                //    return "N";
                //}

                //if (number.Substring(0, 2) == "92")
                //{
                //    number = "0" + number.Substring(2, number.Length - 2);
                //}
                //client.BaseAddress = new Uri("https://vas.wtl.net.pk/");
                //client.DefaultRequestHeaders.Accept.Clear();
                //client.DefaultRequestHeaders.Accept.Add(
                //    new MediaTypeWithQualityHeaderValue("application/json"));
                //HttpResponseMessage response = await client.GetAsync("api/v2/YSkkB4JUSCTZKmRrqiRzCxJI01557484506826/WTL/" + number + "/" + msg);
                //if (response.IsSuccessStatusCode)
                //{
                //    var res = await response.Content.ReadAsStringAsync();
                //    resp = res.Substring(0, 12);
                //}
                //if (resp == "Message Sent")
                //{
                //    return "S";
                //}
                //else
                //{
                //    return "N";
                //}

                //string ip = "";
                //string com = "";
                //try
                //{
                //    //ip = HttpContext.Current.Request.ServerVariables["HTTP_X_FORWARDED_FOR"];
                //    //if (string.IsNullOrEmpty(ip))
                //    //{
                //        ip = HttpContext.Current.Request.UserHostAddress;
                //    //}
                //    com = Dns.GetHostEntry(ip).HostName;

                //}
                //catch (Exception)
                //{ }

                HttpClient client = new HttpClient();
                if (number.Substring(0, 2) == "92")
                {
                    number = "0" + number.Substring(2, number.Length - 2);
                }
                client.BaseAddress = new Uri("https://connect.jazzcmt.com/");
                client.DefaultRequestHeaders.Accept.Clear();
                client.DefaultRequestHeaders.Accept.Add(
                    new MediaTypeWithQualityHeaderValue("application/json"));
                HttpResponseMessage response = await client.GetAsync("sendsms_url.html?Username=03082472494&Password=Jazz@1234&From=AFZAL ELECT&To=" + number + "&Message=" + msg);
                if (response.IsSuccessStatusCode)
                {
                    var res = await response.Content.ReadAsStringAsync();
                    //await WriteLog(ip + "_" + com + "_" + number + "_" + msg+"_"+res);
                    resp = res.Substring(0, 12);
                }
                //if (resp == "Message Sent")
                //{
                    return resp;
                //}
                //else
                //{
                //    return "N";
                //}
            }
            catch (Exception)
            {
                return "Error";
            }
        }
    }
}