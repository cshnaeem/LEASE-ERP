﻿using System;
using System.Collections.Generic;
using System.Data.Entity;
using System.Linq;
using System.Threading.Tasks;

namespace AGEERP.Models
{
    public class DocumentBL
    {
        AGEEntities db = new AGEEntities();

        public async Task<List<DocumentTypesVM>> GetDocumentTypes()
        {
            return await db.Comp_DocumentTypes.Select(x => new DocumentTypesVM()
            {
                Id = x.Id,
                DocType = x.DocType,
                Path = x.Path
            }).ToListAsync();
        }



        //public async Task<List<BankBookVM>> GetAllDocuments(int doctypeid)
        //{
        //    try
        //    {
        //        return await db.Fin_BankBook.Where(x => x.ActiveStatus).Select(x =>
        //        new BankBookVM
        //        {
        //            CurrentChqNo = x.CurrentChqNo,
        //            EndChqNo = x.EndChqNo,
        //            StartChqNo = x.StartChqNo,
        //            AccId = x.AccId,
        //            TransID = x.TransID,
        //            SubCodeDesc = ""//x.Fin_Accounts.SubCodeDesc          To be discussed
        //        }).ToListAsync();
        //    }
        //    catch (Exception)
        //    {
        //        return null;
        //    }
        //}
        public DocumentVM GetFile(int id)
        {
            if (id > 0)
            {
                return (from x in db.Comp_Documents
                        where x.DocId == id
                        select new DocumentVM()
                        {
                            Created = x.Created,
                            Id = x.DocId,
                            Name = x.DocName,
                            Path = x.DocPath,
                            DocTypeId = x.DocTypeId,
                            RefObjId = x.RefObjId,
                            Remarks = x.Remarks,
                            Status = x.Status,
                            UserId = x.UserId,
                            Extension = x.Extension
                        }).FirstOrDefault();
            }
            else
            {
                return new DocumentVM();
            }
        }

        public async Task<List<DocumentVM>> GetAllDocuments(long id, long refobjid)
        {
            if (id > 0 && refobjid > 0)
            {
                //Documents For Employees
                if (refobjid == 1)
                {
                    return await (from x in db.Comp_Documents
                                  join docemp in db.Pay_EmpMaster on x.RefObjId equals docemp.EmpId
                                  where x.DocTypeId == refobjid && x.RefObjId == id
                                  select new DocumentVM()
                                  {
                                      Created = x.Created,
                                      Id = x.DocId,
                                      Name = x.DocName,
                                      Path = x.DocPath,
                                      DocTypeId = x.DocTypeId,
                                      Size = x.Size,
                                      Extension = x.Extension,
                                      HasDirectories = false,
                                      IsDirectory = false,
                                      Modified = x.Modified,
                                      RefObjId = x.RefObjId,
                                      Remarks = x.Remarks,
                                      Status = x.Status,
                                      UserId = x.UserId,
                                      documentowner = docemp.EmpName
                                  }).ToListAsync();
                }
                //Documents for Suppliers
                else if (refobjid == 2)
                {
                    return await (from x in db.Comp_Documents
                                  join supp in db.Inv_Suppliers on x.RefObjId equals supp.SuppId
                                  where x.DocTypeId == refobjid && x.RefObjId == id
                                  select new DocumentVM()
                                  {
                                      Created = x.Created,
                                      Id = x.DocId,
                                      Name = x.DocName,
                                      Path = x.DocPath,
                                      DocTypeId = x.DocTypeId,
                                      Size = x.Size,
                                      Extension = x.Extension,
                                      HasDirectories = false,
                                      IsDirectory = false,
                                      Modified = x.Modified,
                                      RefObjId = x.RefObjId,
                                      Remarks = x.Remarks,
                                      Status = x.Status,
                                      UserId = x.UserId
                                  }).ToListAsync();
                }
                //Documents for Customers -- Have to correct the query
                else if (refobjid == 3)
                {
                    return await (from x in db.Comp_Documents
                                  join user in db.Pay_EmpMaster on x.UserId equals user.EmpId
                                  where x.DocTypeId == refobjid && x.RefObjId == id
                                  select new DocumentVM()
                                  {
                                      Created = x.Created,
                                      Id = x.DocId,
                                      Name = x.DocName,
                                      Path = x.DocPath,
                                      DocTypeId = x.DocTypeId,
                                      Size = x.Size,
                                      Extension = x.Extension,
                                      HasDirectories = false,
                                      IsDirectory = false,
                                      Modified = x.Modified,
                                      RefObjId = x.RefObjId,
                                      Remarks = x.Remarks,
                                      Status = x.Status,
                                      UserId = x.UserId

                                  }).ToListAsync();
                }
                else if (refobjid == 4)
                {
                    return await (from x in db.Comp_Documents
                                  join user in db.Inv_GRN on x.RefObjId equals user.GRNId
                                  where x.DocTypeId == refobjid && x.RefObjId == id
                                  select new DocumentVM()
                                  {
                                      Created = x.Created,
                                      Id = x.DocId,
                                      Name = x.DocName,
                                      Path = x.DocPath,
                                      DocTypeId = x.DocTypeId,
                                      Size = x.Size,
                                      Extension = x.Extension,
                                      HasDirectories = false,
                                      IsDirectory = false,
                                      Modified = x.Modified,
                                      RefObjId = x.RefObjId,
                                      Remarks = x.Remarks,
                                      Status = x.Status,
                                      UserId = x.UserId

                                  }).ToListAsync();
                }
                else if (refobjid == 5)
                {
                    return await (from x in db.Comp_Documents
                                  join user in db.Inv_PO on x.RefObjId equals user.POId
                                  where x.DocTypeId == refobjid && x.RefObjId == id
                                  select new DocumentVM()
                                  {
                                      Created = x.Created,
                                      Id = x.DocId,
                                      Name = x.DocName,
                                      Path = x.DocPath,
                                      DocTypeId = x.DocTypeId,
                                      Size = x.Size,
                                      Extension = x.Extension,
                                      HasDirectories = false,
                                      IsDirectory = false,
                                      Modified = x.Modified,
                                      RefObjId = x.RefObjId,
                                      Remarks = x.Remarks,
                                      Status = x.Status,
                                      UserId = x.UserId

                                  }).ToListAsync();
                }
                else if (refobjid == 6)
                {
                    return await (from x in db.Comp_Documents
                                  join user in db.Lse_ExpenseTransaction on x.RefObjId equals user.TransId
                                  where x.DocTypeId == refobjid && x.RefObjId == id
                                  select new DocumentVM()
                                  {
                                      Created = x.Created,
                                      Id = x.DocId,
                                      Name = x.DocName,
                                      Path = x.DocPath,
                                      DocTypeId = x.DocTypeId,
                                      Size = x.Size,
                                      Extension = x.Extension,
                                      HasDirectories = false,
                                      IsDirectory = false,
                                      Modified = x.Modified,
                                      RefObjId = x.RefObjId,
                                      Remarks = x.Remarks,
                                      Status = x.Status,
                                      UserId = x.UserId

                                  }).ToListAsync();
                }
                else
                {
                    return await (from x in db.Comp_Documents
                                  where x.DocTypeId == refobjid && x.RefObjId == id
                                  select new DocumentVM()
                                  {
                                      Created = x.Created,
                                      Id = x.DocId,
                                      Name = x.DocName,
                                      Path = x.DocPath,
                                      DocTypeId = x.DocTypeId,
                                      Size = x.Size,
                                      Extension = x.Extension,
                                      HasDirectories = false,
                                      IsDirectory = false,
                                      Modified = x.Modified,
                                      RefObjId = x.RefObjId,
                                      Remarks = x.Remarks,
                                      Status = x.Status,
                                      UserId = x.UserId
                                  }).ToListAsync();
                }
            }
            else
            {
                return new List<DocumentVM>();
            }
        }


        public async Task<DocumentVM> AddDocument(DocumentVM model, int UserId)
        {
            try
            {

                if (!String.IsNullOrWhiteSpace(model.Path))
                {
                    Comp_Documents document = new Comp_Documents()
                    {
                        Created = DateTime.Now,
                        DocName = model.Name,
                        DocPath = model.Path,
                        DocTypeId = model.DocTypeId,
                        RefObjId = model.RefObjId,
                        Remarks = model.Remarks,
                        Status = true,
                        UserId = UserId,
                        Extension = model.Extension,
                        Size = model.Size
                    };
                    db.Comp_Documents.Add(document);
                    await db.SaveChangesAsync();
                    model.Id = document.DocId;
                }


                return model;
            }
            catch (Exception ex)
            {
                return null;
            }

        }

        public async Task<bool> RenameDocument(long docid, string filename)
        {
            if (docid > 0)
            {
                var doc = db.Comp_Documents.Where(x => x.DocId == docid).FirstOrDefault();
                if (doc != null)
                {
                    doc.DocName = filename;
                    doc.Modified = DateTime.Now;
                    await db.SaveChangesAsync();
                    return true;
                }
                else
                {
                    return false;
                }
            }
            else
            {
                return false;
            }
        }


        public async Task<bool> UpdateRemarksDocument(long docid, string remarks)
        {
            if (docid > 0)
            {
                var doc = db.Comp_Documents.Where(x => x.DocId == docid).FirstOrDefault();
                if (doc != null)
                {
                    doc.Remarks = remarks;
                    doc.Modified = DateTime.Now;
                    await db.SaveChangesAsync();
                    return true;
                }
                else
                {
                    return false;
                }
            }
            else
            {
                return false;
            }
        }

        public async Task<bool> RemoveDocument(long docid)
        {
            if (docid > 0)
            {
                var doc = db.Comp_Documents.Where(x => x.DocId == docid).FirstOrDefault();
                if (doc != null)
                {
                    doc.Status = false;
                    await db.SaveChangesAsync();
                    return true;
                }
                else
                {
                    return false;
                }
            }
            else
            {
                return false;
            }
        }
        public async Task<bool> UpdateDocRef(List<long> lst, long refobjId)
        {
            try
            {
                if (lst != null)
                {
                    foreach (var v in lst)
                    {
                        var doc = await db.Comp_Documents.Where(x => x.DocId == v).FirstOrDefaultAsync();
                        if (doc != null)
                        {
                            doc.RefObjId = refobjId;
                        }
                    }
                    await db.SaveChangesAsync();
                }
                return true;
            }
            catch (Exception)
            {
                return false;
            }
        }

    }
}