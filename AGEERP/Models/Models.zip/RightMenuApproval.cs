﻿namespace AGEERP.Models
{
    public enum RightMenuApproval
    {
        LeaveRosterHeadApproval = 18050300,
        LeaveRosterHRApproval = 18050400,
        EmployeeLoanApproval = 18100000,
        EmployeeFineApproval = 18200000,
        LeaveRosterApproval = 18050500,
        ClosingVoucher = 14120000,
        LockAccountPrint = 21090000,
        CRCRemarks = 21100000,
        IsInstRight = 14030400,
        IsOrderEditRight = 12230000,
        InvoiceRights = 12100000,
        InstDisc = 21110000,
        OrderSchedule = 12260000

    }
    //public enum FieldListDesg {
    //RO = ,
    //MO = ,
    //AVO = ,
    //SRO = ,
    //MKT = ,
    //}

}