﻿using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Data.Entity;
using System.IO;
using System.Linq;
using System.Net.Http;
using System.Net.Http.Headers;
using System.Text;
using System.Threading.Tasks;

namespace AGEERP.Models
{
    public class TaxBL
    {
        AGEEntities db = new AGEEntities();
        public async Task<string> GetInvoiceNo(int LocId)
        {
            try
            {
                var loc = await db.Comp_Locations.FindAsync(LocId);
                if (loc.FBRPOSID == null)
                {
                    return "";
                }

                var docNo = await db.Tax_Invoice.Where(x => x.LocId == loc.LocId).OrderByDescending(x => x.TransId).Select(x => x.USIN).FirstOrDefaultAsync();
                if (docNo != null)
                {
                    if (docNo.Substring(0, 4) == DateTime.Now.ToString("yyMM"))
                    {
                        docNo = DateTime.Now.ToString("yyMM") + LocId.ToString("000") + (Convert.ToInt32(docNo.Substring(7, 6)) + 1).ToString("000000");
                    }
                    else
                    {
                        docNo = DateTime.Now.ToString("yyMM") + LocId.ToString("000") + "000001";
                    }
                }
                else
                {
                    docNo = DateTime.Now.ToString("yyMM") + LocId.ToString("000") + "000001";
                }
                return docNo;
            }
            catch (Exception)
            {
                return "";
            }
        }

//        public async Task<bool> PostPend()
//        {
//            try
//            {
//                long[] lst =

//                    {
//                    937787,
//934685,
//936173,
//950002,
//935273,
//935385,
//938500,
//949357
//};
//                //var lst = await db.Lse_Master.Where(x => x.DeliveryTransDate > dt && x.Comp_Locations.FBRPOSID > 0 && x.TInvoiceNo == null).Select(x => x.AccNo).ToListAsync();
//                foreach (var v in lst)
//                {
//                    await PostToFBR(v, "I");
//                }
//                return true;
//            }
//            catch (Exception)
//            {
//                return false;
//            }
//        }

        public async Task<bool> PostToFBR(long TransId, string Type)
        {
            try
            {
                var IsExist = await db.Tax_Invoice.Where(x => x.RefTransId == TransId && x.Type == Type).AnyAsync();
                if (IsExist)
                {
                    return false;
                }
                if (Type == "C")
                {
                    
                    var mas = await db.Inv_Sale.FindAsync(TransId);
                    if (!(db.spget_Taxable(TransId, Type).FirstOrDefault().Value))
                    {
                        return false;
                    }

                    var loc = await db.Comp_Locations.FindAsync(mas.LocId);
                    if (loc.FBRPOSID == null)
                    {
                        return false;
                    }

                    var dtlLst = mas.Inv_SaleDetail.ToList();

                    decimal totalBillAmount = 0;
                    decimal totalTaxCharged = 0;
                    int totalQuantity = 0;
                    decimal totalSaleValue = 0;
                    decimal totalDisc = 0;

                    var refUSIN = "";
                    if (mas.TransactionTypeId == 2 || mas.TransactionTypeId == 6)
                    {
                        if (mas.ItemType == "O")
                        {
                            return false;
                        }
                        var preSale = await db.Inv_Sale.FindAsync(mas.RefSaleId);
                        if (preSale.FBRInvoiceNo == null)
                        {
                            return false;
                        }
                        else
                        {
                            refUSIN = preSale.TInvoiceNo;
                        }
                    }

                    string invNo = await GetInvoiceNo(mas.LocId);
                    mas.TInvoiceNo = invNo;
                    mas.IsTaxable = true;

                    List<Tax_InvoiceItems> invDtl = new List<Tax_InvoiceItems>();
                    foreach (var x in dtlLst)
                    {
                        if (x.MRP == 0)
                            continue;

                        Tax_InvoiceItems tbl = new Tax_InvoiceItems();
                        tbl.RefTransDtlId = x.TransDtlId;
                        tbl.Discount = (x.SPrice - x.Discount) < x.MRP ? x.MRP - (x.SPrice - x.Discount) : 0;
                        tbl.FurtherTax = 0;
                        tbl.InvoiceType = (new int[] { 1, 5, 11 }).Contains(mas.TransactionTypeId) ? 1 : 3;
                        var itm = await db.Inv_Store.FindAsync(x.ItemId);
                        tbl.ItemCode = itm.Itm_Master.SKUCode;
                        tbl.PCTCode = itm.Itm_Master.Itm_Model.Itm_Type.Itm_Products.PCTCode;
                        tbl.Quantity = x.Qty;
                        tbl.RefUSIN = refUSIN;
                        tbl.SaleValue = x.MRP - x.Tax ?? 0;
                        tbl.TaxCharged = x.Tax ?? 0;
                        tbl.TaxRate = (double)(itm.Tax ?? 0);
                        tbl.TotalAmount = x.MRP;
                        tbl.ItemName = itm.Itm_Master.Itm_Model.Itm_Type.Itm_Products.ProductName;
                        
                        totalBillAmount = totalBillAmount + tbl.TotalAmount;
                        totalTaxCharged = totalTaxCharged + tbl.TaxCharged;
                        totalQuantity = totalQuantity + tbl.Quantity;
                        totalSaleValue = totalSaleValue + tbl.SaleValue;
                        totalDisc = totalDisc + tbl.Discount ?? 0;

                        invDtl.Add(tbl);

                    }


                    Tax_Invoice inv = new Tax_Invoice()
                    {
                        RefTransId = TransId,
                        InvoiceNumber = "",
                        BuyerCNIC = mas.CustCNIC.Replace("-", ""),
                        BuyerName = mas.CustName,
                        BuyerNTN = mas.CustNTN,
                        BuyerPhoneNumber = "92" + mas.CustCellNo.Replace("-", "").Substring(1, 10),
                        DateTime = mas.TransDate,
                        Discount = totalDisc,
                        FurtherTax = 0,
                        InvoiceType = (new int[] { 1, 5, 11 }).Contains(mas.TransactionTypeId) ? 1 : 3,//new 1 debit 2 credit 3
                        PaymentMode = mas.PaymentModeId == 1 ? 1 : mas.PaymentModeId == 2 ? 2 : mas.PaymentModeId == 3 ? 6 : 1,//Cash 1, Card 2, Cheque 6
                        POSID = loc.FBRPOSID ?? 0,
                        RefUSIN = refUSIN,
                        TotalBillAmount = totalBillAmount,
                        TotalSaleValue = totalSaleValue,
                        TotalTaxCharged = totalTaxCharged,
                        USIN = invNo,
                        TotalQuantity = totalQuantity,
                        Tax_InvoiceItems = invDtl,
                        SyncStatus = false,
                        Type = "C",
                        LocId = mas.LocId
                    };

                    db.Tax_Invoice.Add(inv);
                    await db.SaveChangesAsync();

                }
                else if (Type == "I")
                {
                    var mas = await db.Lse_Master.FindAsync(TransId);
                    if (!(db.spget_Taxable(TransId, Type).FirstOrDefault().Value))
                    {
                        mas.IsTaxable = false;
                        return false;
                    }

                    var dtlLst = mas.Lse_Detail.ToList();
                    var loc = await db.Comp_Locations.FindAsync(mas.LocId);
                    if (loc.FBRPOSID == null)
                    {
                        return false;
                    }

                    decimal totalBillAmount = 0;
                    decimal totalTaxCharged = 0;
                    int totalQuantity = 0;
                    decimal totalSaleValue = 0;


                    string invNo = await GetInvoiceNo(mas.LocId);
                    mas.TInvoiceNo = invNo;
                    mas.IsTaxable = true;

                    List<Tax_InvoiceItems> invDtl = new List<Tax_InvoiceItems>();
                    foreach (var x in dtlLst)
                    {
                        if (x.MRP == 0)
                            continue;

                        Tax_InvoiceItems tbl = new Tax_InvoiceItems();
                        tbl.RefTransDtlId = x.DtlId;
                        tbl.Discount = x.Discount;
                        tbl.FurtherTax = 0;
                        tbl.InvoiceType = 1;
                        var itm = await db.Inv_Store.FindAsync(x.ItemId);
                        tbl.ItemCode = itm.Itm_Master.SKUCode;
                        tbl.PCTCode = itm.Itm_Master.Itm_Model.Itm_Type.Itm_Products.PCTCode;
                        tbl.Quantity = x.Qty;
                        tbl.RefUSIN = "";
                        tbl.SaleValue = x.MRP - x.Tax;
                        tbl.TaxCharged = x.Tax;
                        tbl.TaxRate = (double)(itm.Tax ?? 0);
                        tbl.TotalAmount = x.MRP;
                        tbl.ItemName = itm.Itm_Master.Itm_Model.Itm_Type.Itm_Products.ProductName;

                        totalBillAmount = totalBillAmount + tbl.TotalAmount;
                        totalTaxCharged = totalTaxCharged + tbl.TaxCharged;
                        totalQuantity = totalQuantity + tbl.Quantity;
                        totalSaleValue = totalSaleValue + tbl.SaleValue;

                        invDtl.Add(tbl);

                    }

                    //"92" + mas.Mobile1.Replace("-", "").Substring(1, 11),

                    Tax_Invoice inv = new Tax_Invoice()
                    {
                        RefTransId = TransId,
                        InvoiceNumber = "",
                        BuyerCNIC = mas.NIC.Replace("-", ""),
                        BuyerName = mas.CustName,
                        BuyerNTN = "",
                        BuyerPhoneNumber = "92" + mas.Mobile1.Replace("-", "").Substring(1, 10),
                        DateTime = (DateTime)mas.DeliveryTransDate,
                        Discount = mas.Discount,
                        FurtherTax = 0,
                        InvoiceType = 1,//new 1 debit 2 credit 3
                        PaymentMode = 1,//Cash 1, Card 2, Cheque 6
                        POSID = loc.FBRPOSID ?? 0,
                        RefUSIN = "",
                        TotalBillAmount = totalBillAmount,
                        TotalSaleValue = totalSaleValue,
                        TotalTaxCharged = totalTaxCharged,
                        USIN = invNo,
                        TotalQuantity = totalQuantity,
                        Tax_InvoiceItems = invDtl,
                        SyncStatus = false,
                        Type = "I",
                        LocId = mas.LocId
                    };

                    db.Tax_Invoice.Add(inv);
                    await db.SaveChangesAsync();

                }

                await PostInvoice(TransId, Type);

                return true;
            }
            catch (Exception ex)
            {
                await WriteLog(ex.StackTrace, ex.Message);
                return false;
            }
        }
        public async Task<bool> WriteLog(string trace, string strMessage)
        {
            try
            {
                FileStream objFilestream = new FileStream("D:\\Web\\logs.txt", FileMode.Append, FileAccess.Write);
                StreamWriter objStreamWriter = new StreamWriter((Stream)objFilestream);
                await objStreamWriter.WriteLineAsync(DateTime.Now.ToString()+ "--" + trace + "--" + strMessage);
                objStreamWriter.Close();
                objFilestream.Close();
                return true;
            }
            catch (Exception ex)
            {
                return false;
            }
        }

        public async Task<bool> PostInvoice(long RefTransId, string Type)
        {
            try
            {
                var v = await db.Tax_Invoice.Where(x => x.RefTransId == RefTransId && x.Type == Type && x.SyncStatus == false).SingleOrDefaultAsync();
                if (v != null)
                {
                    Invoice objInv = new Invoice()
                    {
                        InvoiceNumber = v.InvoiceNumber,
                        BuyerCNIC = v.BuyerCNIC,
                        BuyerName = v.BuyerName,
                        BuyerNTN = v.BuyerNTN,
                        BuyerPhoneNumber = v.BuyerPhoneNumber,
                        DateTime = v.DateTime,
                        Discount = v.Discount,
                        FurtherTax = v.FurtherTax,
                        InvoiceType = v.InvoiceType,
                        PaymentMode = v.PaymentMode,
                        POSID = v.POSID,
                        RefUSIN = v.RefUSIN,
                        TotalBillAmount = v.TotalBillAmount,
                        TotalSaleValue = v.TotalSaleValue,
                        TotalTaxCharged = v.TotalTaxCharged,
                        USIN = v.USIN,
                        TotalQuantity = v.TotalQuantity
                    };

                    objInv.Items = db.Tax_InvoiceItems.Where(x => x.TransId == v.TransId).Select(x => new InvoiceItems
                    {
                        Discount = x.Discount,
                        FurtherTax = x.FurtherTax,
                        InvoiceType = x.InvoiceType,
                        ItemCode = x.ItemCode,
                        PCTCode = x.PCTCode,
                        Quantity = x.Quantity,
                        RefUSIN = x.RefUSIN,
                        SaleValue = x.SaleValue,
                        TaxCharged = x.TaxCharged,
                        TaxRate = x.TaxRate,
                        TotalAmount = x.TotalAmount,
                        ItemName = x.ItemName
                    }).ToList();

                    HttpClient client = new HttpClient();
                    client.DefaultRequestHeaders.Authorization = new AuthenticationHeaderValue("Bearer", "1298b5eb-b252-3d97-8622-a4a69d5bf818");
                    StringContent content = new StringContent(JsonConvert.SerializeObject(objInv), Encoding.UTF8, "application/json");
                    System.Net.ServicePointManager.ServerCertificateValidationCallback = delegate { return true; };
                    HttpResponseMessage response = client.PostAsync("https://gw.fbr.gov.pk/imsp/v1/api/Live/PostData", content).Result;
                    if (response != null)
                    {
                        if (response.IsSuccessStatusCode)
                        {
                            var str = response.Content.ReadAsStringAsync().Result;
                            FBRResponse resp = JsonConvert.DeserializeObject<FBRResponse>(response.Content.ReadAsStringAsync().Result);

                            if (resp.Code == 100)
                            {
                                v.SyncDate = DateTime.Now;
                                v.SyncStatus = true;
                            }
                            v.InvoiceNumber = resp.InvoiceNumber ?? "";
                            v.Code = resp.Code;
                            v.Response = resp.Response;

                            if (Type == "C")
                            {
                                var mas = await db.Inv_Sale.FindAsync(RefTransId);
                                mas.FBRInvoiceNo = resp.InvoiceNumber ?? "";
                                mas.Response = resp.Response;
                            }
                            else if (Type == "I")
                            {
                                var mas = await db.Lse_Master.FindAsync(RefTransId);
                                mas.FBRInvoiceNo = resp.InvoiceNumber ?? "";
                            }


                        }
                        else
                        {
                            v.Response = "Not Responding";
                        }
                    }
                    else
                    {
                        v.Response = "Null Response";
                    }
                    await db.SaveChangesAsync();
                }
                return true;
            }
            catch (Exception ex)
            {
                await WriteLog(ex.StackTrace, ex.Message);
                return false;
            }
        }

        public async Task<bool> PostPending()
        {
            try
            {
                var dt = DateTime.Now.AddMinutes(5);
                //var fromDt = Convert.ToDateTime("2021-06-01");
                var lst = await db.Tax_Invoice.Where(x => x.SyncStatus == false && x.DateTime < dt).ToListAsync();
                foreach (var v in lst)
                {
                    await PostInvoice(v.RefTransId, v.Type);
                }
                return true;
            }
            catch (Exception ex)
            {
                await WriteLog(ex.StackTrace, ex.Message);
                return false;
            }
        }
    }

    public class FBRResponse
    {
        public string InvoiceNumber { get; set; }
        public string Response { get; set; }
        public int Code { get; set; }
    }
    public class Invoice
    {
        public string InvoiceNumber { get; set; }
        public long POSID { get; set; }
        public string USIN { get; set; }
        public string RefUSIN { get; set; }
        public System.DateTime DateTime { get; set; }
        public string BuyerName { get; set; }
        public string BuyerNTN { get; set; }
        public string BuyerCNIC { get; set; }
        public string BuyerPhoneNumber { get; set; }
        public decimal TotalSaleValue { get; set; }
        public decimal TotalTaxCharged { get; set; }
        public Nullable<decimal> Discount { get; set; }
        public Nullable<decimal> FurtherTax { get; set; }
        public decimal TotalBillAmount { get; set; }
        public decimal TotalQuantity { get; set; }
        public int PaymentMode { get; set; }
        public int InvoiceType { get; set; }
        public List<InvoiceItems> Items { get; set; }
    }
    public class InvoiceItems
    {
        public string ItemCode { get; set; }
        public string ItemName { get; set; }
        public string PCTCode { get; set; }
        public decimal Quantity { get; set; }
        public double TaxRate { get; set; }
        public decimal SaleValue { get; set; }
        public Nullable<decimal> Discount { get; set; }
        public Nullable<decimal> FurtherTax { get; set; }
        public decimal TaxCharged { get; set; }
        public decimal TotalAmount { get; set; }
        public int InvoiceType { get; set; }
        public string RefUSIN { get; set; }
    }
}
